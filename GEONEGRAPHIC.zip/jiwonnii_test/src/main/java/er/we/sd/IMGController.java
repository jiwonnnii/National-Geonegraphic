package er.we.sd;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;


import dao.IMGMapper;
import dao.MemberMapper;
import vo.IMG;
import vo.Member;
@Controller
public class IMGController {
	
	
	@Autowired
	SqlSession session;
	
	
	@RequestMapping(value = "/saveIMG", method = RequestMethod.POST, produces = "application/text; charset=utf8")
	public String saveIMG(IMG savedimg,  HttpSession hs) {
	
		System.out.println(savedimg);
		savedimg.setUseremail((String)hs.getAttribute("useremail"));
		IMGMapper mapper = session.getMapper(IMGMapper.class);
		

		mapper.addIMG(savedimg);
		
		return "Camera";
	}

	@RequestMapping(value = "/searchContent", method = RequestMethod.GET)
	public String searchContent(String content, HttpSession hs, Model model) {
		//System.out.println(content);
		IMGMapper mapper = session.getMapper(IMGMapper.class);
		
		
		List<IMG> searchIMG = mapper.searchIMG((String)hs.getAttribute("useremail"));
	//	System.out.println(searchIMG);
		
		List<IMG> resultIMG = new ArrayList<IMG>();
		
		for(int i=0; i<searchIMG.size(); i++) {
			if(searchIMG.get(i).getContent().contains(content)) {
				//System.out.println(searchIMG.get(i));
				resultIMG.add(searchIMG.get(i));
			}
		}
		
		model.addAttribute("resultIMG", resultIMG);
		System.out.println(resultIMG);

/*		if(loginMem != null) {
			hs.setAttribute("useremail", loginMem.getUseremail());
			hs.setAttribute("username", loginMem.getUsername());
		}*/
		return "Storage";
	}
	
	
	
}
