package er.we.sd;


import javax.servlet.http.HttpSession;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import dao.MemberMapper;
import vo.Member;



@Controller
public class MemberController {
	
	
	@Autowired
	SqlSession session;
	
	@RequestMapping(value = "/duplicateCheck", method = RequestMethod.POST, produces = "application/text; charset=utf8")
	public @ResponseBody int duplicateCheck(String email) {
		MemberMapper mapper = session.getMapper(MemberMapper.class);
		int result = mapper.duplicateCheck(email);
		
		return result;
	}
	
	
	@RequestMapping(value = "/addMember", method = RequestMethod.GET)
	public String addMember(Member member) {
		System.out.println(member);
		MemberMapper mapper = session.getMapper(MemberMapper.class);
		mapper.addMember(member);
		return "home";
	}
	
	
	
	@RequestMapping(value = "/login", method = RequestMethod.GET)
	public String login(Member member, HttpSession hs) {

		MemberMapper mapper = session.getMapper(MemberMapper.class);
		
		Member loginMem = mapper.login(member);
		System.out.println(loginMem);
		if(loginMem != null) {
			hs.setAttribute("useremail", loginMem.getUseremail());
			hs.setAttribute("username", loginMem.getUsername());
		}
		return "home";
	}
	
	
	
}
