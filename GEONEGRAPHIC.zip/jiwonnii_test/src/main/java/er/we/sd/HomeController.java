package er.we.sd;

import java.text.DateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import javax.servlet.http.HttpSession;

import org.apache.ibatis.session.SqlSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import dao.IMGMapper;
import vo.IMG;

/**
 * Handles requests for the application home page.
 */
@Controller
public class HomeController {
	
	@Autowired
	SqlSession session;
	
	private static final Logger logger = LoggerFactory.getLogger(HomeController.class);
	
	/**
	 * Simply selects the home view to render by returning its name.
	 */
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String home(Locale locale, Model model) {
		logger.info("Welcome home! The client locale is {}.", locale);
		
		Date date = new Date();
		DateFormat dateFormat = DateFormat.getDateTimeInstance(DateFormat.LONG, DateFormat.LONG, locale);
		
		String formattedDate = dateFormat.format(date);
		
		model.addAttribute("serverTime", formattedDate );
		
		return "home";
	}
	@RequestMapping(value = "/gotoHome", method = RequestMethod.GET)
	public String gotoHome() {

		return "home";
	}
	
	
	@RequestMapping(value = "/gotoCamera", method = RequestMethod.GET)
	public String gotoCamera() {
	
		
		return "Camera";
	}
	
	@RequestMapping(value = "/gotoUpload", method = RequestMethod.GET)
	public String gotoUpload() {
	
		
		return "Upload";
	}
	@RequestMapping(value = "/gotoStorage", method = RequestMethod.GET)
	public String gotoStorage(HttpSession hs, Model model) {
		
/*		IMGMapper mapper = session.getMapper(IMGMapper.class);
		//IMG myIMG = new IMG();
		List<IMG> lIMG = mapper.IMGList((String)hs.getAttribute("useremail"));
		if(lIMG !=null) {
			model.addAttribute("lIMG", lIMG);
		model.addAttribute("Dataurl", myIMG.getDataurl());
		model.addAttribute("Content", myIMG.getContent());
		model.addAttribute("regdate", myIMG.getRegdate());
		}		*/
		
		return "Storage";
	}
	@RequestMapping(value = "/gotoJoin", method = RequestMethod.GET)
	public String gotoJoin() {
	
		
		return "Join";
	}
	
	@RequestMapping(value = "/gotologin", method = RequestMethod.GET)
	public String gotologin() {
	
		
		return "Login";
	}
	@RequestMapping(value = "/logout", method = RequestMethod.GET)
	public String logout(HttpSession hs) {
		hs.invalidate();
		return "home";
	}
	
	@RequestMapping(value = "/ajaxImage", method = RequestMethod.POST)
	public @ResponseBody List<IMG> ajaxImage(HttpSession hs, Model model) {
		
		IMGMapper mapper = session.getMapper(IMGMapper.class);
		List<IMG> lIMG = mapper.IMGList((String)hs.getAttribute("useremail"));
		
		for(IMG img : lIMG) {
			System.out.println(img.toString());
		}
		
		return lIMG;
	}
	
	
	


}
