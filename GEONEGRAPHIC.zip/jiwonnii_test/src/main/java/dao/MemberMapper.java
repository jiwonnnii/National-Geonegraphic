package dao;

import vo.Member;

public interface MemberMapper {
	public int addMember(Member member);
	public int duplicateCheck(String email);

	public Member login (Member member);
}
