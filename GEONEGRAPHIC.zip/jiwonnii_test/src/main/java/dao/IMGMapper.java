package dao;

import java.util.List;

import vo.IMG;

public interface IMGMapper {
	

	public int addIMG(IMG img);
	
	public List<IMG> IMGList(String useremail);
	
	public List<IMG> searchIMG(String useremail);

}
