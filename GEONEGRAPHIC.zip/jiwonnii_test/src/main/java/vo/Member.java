package vo;

public class Member {
	public String useremail;				// ȸ���̸���
	public String username;					// ȸ���̸�
	public String userpassword;				// ȸ���н�����
	public Member(String useremail, String username, String userpassword) {
		super();
		this.useremail = useremail;
		this.username = username;
		this.userpassword = userpassword;
	}
	public Member() {
		super();
	}
	public String getUseremail() {
		return useremail;
	}
	public void setUseremail(String useremail) {
		this.useremail = useremail;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getUserpassword() {
		return userpassword;
	}
	public void setUserpassword(String userpassword) {
		this.userpassword = userpassword;
	}
	@Override
	public String toString() {
		return "Member [useremail=" + useremail + ", username=" + username + ", userpassword=" + userpassword + "]";
	}


}
