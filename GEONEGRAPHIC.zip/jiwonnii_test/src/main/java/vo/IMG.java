package vo;

public class IMG {
	public String imgseq;
	public String useremail;
	public String dataurl;
	public String content;
	public String regdate;
	public IMG(String imgseq, String useremail, String dataurl, String content, String regdate) {
		super();
		this.imgseq = imgseq;
		this.useremail = useremail;
		this.dataurl = dataurl;
		this.content = content;
		this.regdate = regdate;
	}
	public IMG() {
		super();
	}
	public String getImgseq() {
		return imgseq;
	}
	public void setImgseq(String imgseq) {
		this.imgseq = imgseq;
	}
	public String getUseremail() {
		return useremail;
	}
	public void setUseremail(String useremail) {
		this.useremail = useremail;
	}
	public String getDataurl() {
		return dataurl;
	}
	public void setDataurl(String dataurl) {
		this.dataurl = dataurl;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getRegdate() {
		return regdate;
	}
	public void setRegdate(String regdate) {
		this.regdate = regdate;
	}
	@Override
	public String toString() {
		return "IMG [imgseq=" + imgseq + ", useremail=" + useremail + ", dataurl=" + dataurl + ", content=" + content
				+ ", regdate=" + regdate + "]";
	}

	
	
	

}
