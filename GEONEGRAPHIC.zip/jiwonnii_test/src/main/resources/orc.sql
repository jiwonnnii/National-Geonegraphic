﻿-- 회원 정보 테이블
create table jwMember (
	useremail		varchar2(100)	primary key not null,   	-- 회원 이메일
	username 	varchar2(15) 	not null, 			-- 회원 이름
	userpassword 	varchar2(10)	 not null  			-- 회원 비밀번호
);


-- 이미지 정보 테이블
create table imgInfo(
	imgseq 		number		primary key,		-- 이미지 등록순서
	useremail		varchar2(100)	not null constraint email_fk references jwMember,	-- 등록한 회원이메일	
	dataurl		clob		not null,			-- 이미지 데이터 url
	content		varchar2(1000)				-- 이미지 속 내용
);



--이미지 등록순서
create sequence imgseq;

