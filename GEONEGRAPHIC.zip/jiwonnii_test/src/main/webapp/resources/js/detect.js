(function() {

var saveDataURL = '';
var saveContent = '';  


const api_key = `AIzaSyBxL8lSF2EhxlMJ2h_QDxPJYRIUPtWc5aQ`;
  const url = `https://vision.googleapis.com/v1/images:annotate`;
  // Send API Request to Cloud Vision API`
  const sendAPI = (base64string) => {// 여기에 imgData넣으면도
    let body = {
      requests: [
        {image: {content: base64string}, features: [{type: 'TEXT_DETECTION'}]}
      ]
    };
    let xhr = new XMLHttpRequest();
    xhr.open('POST', `${url}?key=${api_key}`, true);
    xhr.setRequestHeader('Content-Type', 'application/json');
    console.log(base64string);
    const p = new Promise((resolve, reject) => {
      xhr.onreadystatechange = () => {
        if (xhr.readyState != XMLHttpRequest.DONE) return;
        if (xhr.status >= 400) return reject({message: `Failed with ${xhr.status}:${xhr.statusText}`});
        resolve(JSON.parse(xhr.responseText));
       // alert(xhr.responseText);
      };
    })
    xhr.send(JSON.stringify(body)); // ajax수행
    saveDataURL=base64string;
   
    return p;
  }
  
  
  // Read input file
  const readFile = (file) => {
    let reader = new FileReader();
    const p = new Promise((resolve, reject) => {
      reader.onload = (ev) => {
        document.querySelector('img').setAttribute('src', ev.target.result);
        resolve(ev.target.result.replace(/^data:image\/(png|jpeg);base64,/, ''));
      };
    })
    reader.readAsDataURL(file);

    
    return p;
  };
  // Event handling
  document.querySelector('input').addEventListener('change', ev => {
    if (!ev.target.files || ev.target.files.length == 0) return;
    Promise.resolve(ev.target.files[0])
      .then(readFile)
     .then(sendAPI)
      .then(res => {
  
        console.log('SUCCESS!', res);
        
        
        var jiwon = JSON.parse(JSON.stringify(res, null, 2));///-----------------------
   //     document.querySelector('pre').innerHTML = JSON.stringify(jiwon.responses);
    //    
        var jiwon2 = JSON.parse(JSON.stringify(jiwon.responses));//-------------------------
        var jiwon2 = jiwon.responses;
        var jiwon3 = jiwon2[0].textAnnotations;
    //    alert(jiwon3[0].description);
        
    //    var jiwon3 = JSON.parse(JSON.stringify(jiwon2[0].textAnnotations));//-------------------------
        
     //   document.querySelector('pre').innerHTML = JSON.stringify(jiwon3[0].description);			//★★★★★
        document.querySelector('pre').innerHTML = jiwon3[0].description;
        saveContent = jiwon3[0].description;
      
       // alert(jiwon3[0].description);
       // document.querySelector('pre').innerHTML = JSON.stringify(res, null, 2);							// base64string는 이미지 url JSON.stringify(res, null, 2) 결과값임!		

       
      })
      .catch(err => {
        console.log('FAILED:(', err);
        document.querySelector('pre').innerHTML = JSON.stringify(err, null, 2);
      });
  });
  
  
  
  
	
	// ---------------------------------------------------------------------------
	
	document.getElementById('Save').addEventListener('click', function() {
		//alert(saveDataURL);
			// alert(saveContent);
		//	alert(saveContent);*/
		if(saveDataURL == '' || saveContent == '' ){
			alert('저장할 이미지가 없습니다.');
		}else{

			$.ajax({
				url:"saveIMG"
				,method:"POST"
				,data :{
					"dataurl": saveDataURL
					, "content" : saveContent	
					
				}, success : function(){
					
				}
				
			});
		}
			
	});
		
})();
	
		
		// ----------------------------------------------------------------------------