(function() {
	var saveDataURL = '';
	var saveContent = '';
	
	

	var video = document.getElementById('video'), 
	canvas = document.getElementById('canvas'), 
	context = canvas.getContext('2d'), 
	vendorUrl = window.URL|| window.webkitURL;
	
	
	
	navigator.getMedia = (navigator.getUserMedia
			|| navigator.webkitGetUserMedia || navigator.mozGetUserMedia || navigator.msGetUserMedia);

	navigator.getMedia({
		video : true,
		audio : false

	},

	function(stream) {

		if (navigator.mozGetUserMedia) {
			video.mozSrcObject = stream;
		} else {
			var vendorURL = window.URL || window.webkitURL;
			video.src = vendorURL.createObjectURL(stream);
		}
		video.play();
	}, function(error) {

	});

	document.getElementById('capture').addEventListener('click', function() {
		/*context.drawImage(video, 0, 0, 400, 300);
		// 캔버스의 이미지를 png형태로 가져오기.
		var imgData = canvas.toDataURL('image/png;base64');	
		 imgData=imgData.split("VR4X")[1]; 
		imgData=imgData.split(",")[1];
		
	
		 saveDataURL = imgData;*/
		
		
		
		
		
		
		context.drawImage(video, 0, 0, 400, 300);
		// 캔버스의 이미지를 png형태로 가져오기.
		  var imgData = canvas.toDataURL('image/png',1,0);
	
		  imgData=imgData.split(",")[1];
	
		 saveDataURL = imgData;
		 
		 
		 
		 
		 
		 
		 
		 
		 
		 
	// alert(imgData);
	/*
	 * var resizedImage = dataURLToBlob(imgData); alert(resizedImage);
	 */
		// 새로운 창을 열고 거기에 이미지보여주기
		// var w = window.open();
		// w.document.write('<img src="' + imgData + '"/>');
		
		
// ------------------------------------------------------------------------------------------------------------
		 const api_key = 'AIzaSyBxL8lSF2EhxlMJ2h_QDxPJYRIUPtWc5aQ';
		  const url = 'https://vision.googleapis.com/v1/images:annotate';
		  // Send API Request to Cloud Vision API
		
		  
	  
		  const sendAPI = (imgData) => {// 여기에 imgData넣으면됨.
		    let body = {
		      requests: [
		        {image: {content: imgData}, features: [{type: 'TEXT_DETECTION'}]}
		      ]
		    };
		    // alert(imgData);
		    console.log(imgData);
		    let xhr = new XMLHttpRequest();
		    xhr.open('POST', `${url}?key=${api_key}`, true);
		    xhr.setRequestHeader('Content-Type', 'application/json');
		    const p = new Promise((resolve, reject) => {
		      xhr.onreadystatechange = () => {
		        if (xhr.readyState != XMLHttpRequest.DONE) return;
		        if (xhr.status >= 400) return reject({message: `Failed with ${xhr.status}:${xhr.statusText}`});
		        resolve(JSON.parse(xhr.responseText));
		      };
		    })
		    xhr.send(JSON.stringify(body));
		    
		    return p;
		  }
		  
		  Promise.resolve(imgData)
		  .then(sendAPI)
		  .then(res=>{
		        console.log('SUCCESS!', res);
		        
		        
		        var jiwon = JSON.parse(JSON.stringify(res, null, 2));// /-----------------------
		        // document.querySelector('pre').innerHTML =
				// JSON.stringify(jiwon.responses);
		         //    
		             var jiwon2 = JSON.parse(JSON.stringify(jiwon.responses));// -------------------------
		             var jiwon2 = jiwon.responses;
		             var jiwon3 = jiwon2[0].textAnnotations;
		         // alert(jiwon3[0].description);
		             
		         // var jiwon3 =
					// JSON.parse(JSON.stringify(jiwon2[0].textAnnotations));//-------------------------
		             
		          // document.querySelector('pre').innerHTML =
					// JSON.stringify(jiwon3[0].description); //★★★★★
		             document.querySelector('pre').innerHTML = jiwon3[0].description;
		           
		         	saveContent = jiwon3[0].description;
		        
		       // document.querySelector('pre').innerHTML = JSON.stringify(res,
				// null, 2); //imgData는 사진 url JSON.stringify(res, null, 2) 결과값임
		        
		      })
		      .catch(err => {
		        console.log('FAILED:(', err);
		        document.querySelector('pre').innerHTML = JSON.stringify(err, null, 2);
		      });
	      
			


		  
		 


	});
	
	
	// ---------------------------------------------------------------------------
	
	document.getElementById('Save').addEventListener('click', function() {
		//	alert(saveContent);*/
		if(saveDataURL == '' || saveContent == '' ){
			alert('저장할 이미지가 없습니다.');
		}else{

			$.ajax({
				url:"saveIMG"
				,method:"POST"
				,data :{
					"dataurl": saveDataURL
					, "content" : saveContent	
					
				}, success : function(){
					
				}
				
			});
		}
			
	});
		
		
		// ----------------------------------------------------------------------------
	

	
})();


